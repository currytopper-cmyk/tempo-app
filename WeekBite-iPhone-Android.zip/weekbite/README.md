# WeekBite

A native Expo / React Native prototype for iPhone and Android. It builds a seven-day menu of healthy, everyday breakfasts, lunches, and dinners, with recipes and a grocery checklist.

## Try it on your phone

1. Extract the ZIP completely. Open the `weekbite` folder inside it.
2. Install a current Node.js LTS release (at least 22.13) on your computer and the current **Expo Go** app on your phone.
3. On Windows, double-click **Start-WeekBite.bat**. Or open a terminal in the `weekbite` folder and run:

```sh
npm ci
npm start
```

4. Keep your computer and phone on the same Wi-Fi. Scan the terminal's QR code using your iPhone camera or the scanner in Expo Go on Android. Keep the terminal running while you use the prototype.

If Expo asks you to sign in, run `npx expo login` on the computer and sign in to the same account in Expo Go. If your network prevents a local connection, stop the server with Ctrl+C and try `npm run start:tunnel`; Expo may ask to install its tunnel helper. You do not need to disable Windows Security.

For a computer-only preview, run `npm run web`. The same React Native screens also render in a browser.

Official setup references: [Expo start guide](https://docs.expo.dev/get-started/start-developing/) and [Expo SDK 57 requirements](https://docs.expo.dev/versions/v57.0.0/).

## What works

- A complete seven-day menu with 21 meal slots, generated from 31 original recipe ideas.
- Tap any day or meal to view its ingredient quantities and cooking steps.
- Swap an individual meal without changing the rest of the week.
- Choose everyday variety or vegetarian meals, cooking time, servings, and listed ingredients to avoid.
- A grouped grocery list that combines quantities across the entire week and scales with servings. Checking an item saves its state on the current device. Swapping a meal unchecks items whose needed quantities change.
- Save favorite recipes. Plus and Family can also save and restore complete weekly plans.
- Demo membership upgrades and downgrades with clear confirmation screens. There are no card fields, payment requests, or recurring charges.
- Family can open the phone's share sheet with the grocery list. In a supported desktop browser, it copies the list if native sharing is unavailable.
- Plans, favorites, grocery checks, and demo membership selections persist on this device using AsyncStorage.

The generator selects matching recipes from the included collection; it does not call an AI service or require API keys. With restrictive preferences, matching recipes repeat to fill the week. Times are estimates; larger batches may take longer. Overnight oats also need overnight chilling, as shown in their recipe.

Recipe portions are starting points for planning. Add snacks, sides, or more food to suit your appetite. Ingredient filters use recipe metadata; product labels and cross-contact information still matter for allergies.

## Memberships included

These are **suggested future monthly prices**. All three plans are free to try in this prototype.

| Feature | Free — $0 | Plus — $4.99/month | Family — $9.99/month |
| --- | --- | --- | --- |
| Generate and swap weekly meals | Yes | Yes | Yes |
| Preferences and grocery checklist | Yes | Yes | Yes |
| Servings per meal | 1–2 | 1–4 | 1–8 |
| Favorite recipes | 5 | Unlimited | Unlimited |
| Saved weekly plans | 0 | 10 | 30 |
| Share grocery list | — | — | Yes |

To test an upgrade, open **Plans → Try Plus demo / Try Family demo → Activate demo**. Return to Free from the same screen. Downgrading keeps existing saved content, limits new saves, and scales the current menu to the new serving limit. Restoring a saved week requires a plan that supports its serving count.

Family means larger portions and grocery-list sharing in this version. It does not include multiple accounts or synchronized household data.

## Suggested first test

1. Open **My week**, change a day, and tap a recipe.
2. Tap **Meal preferences**, choose Vegetarian, and generate a new week.
3. Swap one dinner and inspect **Groceries**. Check several items, close the app, and reopen it.
4. Save five recipes on Free. Try saving a sixth, then activate the Plus demo and try again.
5. Save the current week with the bookmark button. Generate another week and restore the saved one from **My kitchen**.
6. Activate Family, increase the servings, generate a new week, and use grocery sharing.
7. Return to Free and confirm the current serving count returns to no more than two.

## Project layout

| File | Purpose |
| --- | --- |
| `src/WeekBite.tsx` | App screens, navigation, and local persistence |
| `src/panels.tsx` | Recipe, preferences, and membership dialogs |
| `src/planner.ts` | Meal generation, swaps, groceries, dates, and saved-data validation |
| `src/memberships.ts` | Demo feature limits and membership transitions |
| `src/recipes.ts` | Original recipe catalog and ingredient metadata |
| `src/theme.ts`, `src/ui.tsx` | App styling and reusable controls |
| `app.json` | App name, icons, and platform settings |
| `tests/` | Generator, quantity, persistence, and membership checks |

To change prices or membership limits, edit `MEMBERSHIPS` in `src/planner.ts`.

## Verification and current limits

The TypeScript check and nine automated checks pass. The recipe test covers 1,536 supported combinations of meal style, time, and ingredient exclusions. Expo exports successfully for iOS, Android, and web, including native Hermes bundles.

The available browser could not access the local preview. Visual interaction checks and physical-device testing have not been completed. Use the short test above in Expo Go before sharing the prototype with testers.

This ZIP contains the app source and setup instructions, not a signed APK, IPA, or App Store / Play Store release. No real subscriptions, accounts, or server synchronization are connected. Store release would require your own app identifiers, platform signing and store setup, device testing, and production purchase integration. `com.example.weekbite` is a placeholder identifier in `app.json`.

Developer commands:

```sh
npm run typecheck
npm test
npm run export:all
```

## Artwork

`assets/meal-header.png` was created with the built-in image-generation tool for this app. It is decorative meal inspiration rather than an exact photograph of every recipe. The app icon is a simple original text monogram.

Image prompt: “Use case: photorealistic-natural. Create one premium editorial food photograph to use as the header of WeekBite, a healthy everyday weekly meal-planning mobile app. Landscape 1536 by 1024. A generously filled white ceramic bowl of brown rice, roasted chickpeas, cherry tomatoes, cucumber, avocado and fresh herbs; a small second bowl of yogurt with berries partially visible, lemon and linen napkin at edges. On a clean pale peach table, fresh afternoon natural light, tactile appetizing food, elegant food magazine photography with vivid fresh greens and warm orange tones. Main bowl on right side, left third has clear pale peach negative space suitable for app text overlay. No text, no branding, no hands, no utensils crossing the frame. Healthy everyday food, no calorie or diet labels.”
