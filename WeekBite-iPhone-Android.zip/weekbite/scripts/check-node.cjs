const [major,minor]=process.versions.node.split('.').map(Number);
if(major<22||(major===22&&minor<13)) {
 console.error('WeekBite needs Node.js 22.13 or newer. Install a current LTS release from https://nodejs.org.');
 process.exit(1);
}
console.log('Starting WeekBite with Node.js '+process.versions.node);
