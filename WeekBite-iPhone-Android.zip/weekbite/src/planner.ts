import { RECIPES, RECIPE_MAP, type Recipe, type Meal, type Allergen, type Ingredient } from './recipes.ts';
export const MEALS: Meal[] = ['breakfast','lunch','dinner'];
export const DAYS = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
export type Tier = 'free' | 'plus' | 'family';
export type Preferences = {servings:number; style:'everyday'|'vegetarian'; maxMinutes:20|30|60; avoid:Allergen[]};
export type DayPlan = Record<Meal,string>;
export type WeekPlan = {id:string; createdAt:string; weekOf:string; preferences:Preferences; days:DayPlan[]};
export type SavedWeek = WeekPlan;
export const DEFAULT_PREFS:Preferences = {servings:2, style:'everyday', maxMinutes:30, avoid:[]};
export const MEMBERSHIPS = {
 free:{name:'Free',price:0,servings:2,favorites:5,savedWeeks:0,tag:'Your everyday start',features:['A fresh 7-day meal plan','Automatic grocery checklist','Up to 2 servings per meal','Save 5 favorite recipes']},
 plus:{name:'Plus',price:4.99,servings:4,favorites:Infinity,savedWeeks:10,tag:'More room for your favorites',features:['Everything in Free','Unlimited favorite recipes','Save up to 10 weekly plans','Up to 4 servings per meal']},
 family:{name:'Family',price:9.99,servings:8,favorites:Infinity,savedWeeks:30,tag:'Good food for the whole table',features:['Everything in Plus','Up to 8 servings per meal','Save up to 30 weekly plans','Share your grocery list']},
} as const;
export function startOfWeek(date=new Date()):string {const d=new Date(date);d.setHours(12,0,0,0);d.setDate(d.getDate()-((d.getDay()+6)%7));return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
export function fits(recipe:Recipe,prefs:Preferences) {return (prefs.style==='everyday'||recipe.vegetarian)&&recipe.minutes<=prefs.maxMinutes&&!recipe.allergens.some(a=>prefs.avoid.includes(a));}
export function choices(meal:Meal,prefs:Preferences):Recipe[] {return RECIPES.filter(r=>r.meal===meal&&fits(r,prefs));}
export function shuffled<T>(items:T[],random= Math.random):T[] {const a=[...items];for(let n=a.length-1;n>0;n--){const j=Math.floor(random()*(n+1));[a[n],a[j]]=[a[j],a[n]];}return a;}
export function generateWeek(prefs:Preferences,random=Math.random):WeekPlan {
 if(!Number.isInteger(prefs.servings)||prefs.servings<1||prefs.servings>8) throw new Error('Choose between 1 and 8 servings.');
 const pools=Object.fromEntries(MEALS.map(m=>[m,shuffled(choices(m,prefs),random)])) as Record<Meal,Recipe[]>;
 const missing=MEALS.filter(m=>!pools[m].length);
 if(missing.length) throw new Error(`No ${missing.join(' or ')} recipes match yet. Try a longer cooking time or adjust your food preferences.`);
 const days=Array.from({length:7},(_,d)=>Object.fromEntries(MEALS.map(m=>[m,pools[m][d%pools[m].length].id])) as DayPlan);
 return {id:`week-${Date.now()}-${Math.floor(random()*1e8).toString(36)}`,createdAt:new Date().toISOString(),weekOf:startOfWeek(),preferences:{...prefs,avoid:[...prefs.avoid]},days};
}
export function swapMeal(plan:WeekPlan,day:number,meal:Meal,random=Math.random):WeekPlan {
 const current=plan.days[day][meal];const pool=choices(meal,plan.preferences).filter(r=>r.id!==current);
 if(!pool.length) throw new Error('This is the only matching recipe. Adjust your preferences to see more options.');
 const used=plan.days.map(d=>d[meal]);const unused=pool.filter(r=>!used.includes(r.id));const options=unused.length?unused:pool;
 const next=options[Math.floor(random()*options.length)];
 return {...plan,days:plan.days.map((d,n)=>n===day?{...d,[meal]:next.id}:d)};
}
export type Grocery = Ingredient & {key:string};
export function groceries(plan:WeekPlan):Grocery[] {
 const map=new Map<string,Grocery>();
 plan.days.forEach(day=>MEALS.forEach(meal=>RECIPE_MAP[day[meal]].ingredients.forEach(ingredient=>{
  const key=`${ingredient.name}|${ingredient.unit}`;const existing=map.get(key);const amount=ingredient.amount*plan.preferences.servings;
  if(existing)existing.amount+=amount;else map.set(key,{...ingredient,amount,key});
 })));
 return [...map.values()].sort((a,b)=>a.category.localeCompare(b.category)||a.name.localeCompare(b.name));
}
export function quantity(amount:number,unit:string) {const n=Number(amount.toFixed(2));if(unit==='g'&&n>=1000)return `${Number((n/1000).toFixed(2))} kg`;if(unit==='ml'&&n>=1000)return `${Number((n/1000).toFixed(2))} L`;return `${n}${unit==='each'?'':` ${unit}`}`;}
export function dateForDay(weekOf:string,index:number):Date {const d=new Date(`${weekOf}T12:00:00`);d.setDate(d.getDate()+index);return d;}
export type AppState = {version:1; tier:Tier; plan:WeekPlan; favorites:string[]; saved:SavedWeek[]; checked:string[]};
export function initialState():AppState {return {version:1,tier:'free',plan:generateWeek(DEFAULT_PREFS),favorites:[],saved:[],checked:[]};}
export function validPlan(value:unknown):value is WeekPlan {
 const p=value as WeekPlan|undefined;if(!p||typeof p.id!=='string'||typeof p.createdAt!=='string'||typeof p.weekOf!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(p.weekOf)||!Number.isFinite(new Date(p.weekOf).getTime()))return false;
 const prefs=p.preferences;if(!prefs||!Number.isInteger(prefs.servings)||prefs.servings<1||prefs.servings>8||!['everyday','vegetarian'].includes(prefs.style)||![20,30,60].includes(prefs.maxMinutes)||!Array.isArray(prefs.avoid))return false;
 const allergens=['Milk','Egg','Wheat','Soy','Peanut','Tree nut','Fish','Sesame'];if(!prefs.avoid.every(a=>allergens.includes(a)))return false;
 return Array.isArray(p.days)&&p.days.length===7&&p.days.every(d=>d&&MEALS.every(m=>RECIPE_MAP[d[m]]?.meal===m&&fits(RECIPE_MAP[d[m]],prefs)));
}
export function hydrateState(raw:string):AppState {
 const s=JSON.parse(raw) as AppState;
 if(s.version!==1||!['free','plus','family'].includes(s.tier)||!validPlan(s.plan)||!Array.isArray(s.favorites)||!Array.isArray(s.saved)||!Array.isArray(s.checked))throw new Error('Saved data is not compatible.');
 return {...s,favorites:[...new Set(s.favorites.filter(id=>RECIPE_MAP[id]))],saved:s.saved.filter(validPlan),checked:s.checked.filter(x=>typeof x==='string')};
}
