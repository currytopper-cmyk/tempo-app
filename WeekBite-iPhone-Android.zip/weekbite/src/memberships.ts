import { MEMBERSHIPS, type AppState, type Tier, type WeekPlan } from './planner.ts';
export function changeMembership(state:AppState,tier:Tier):AppState {
 return {...state,tier,plan:{...state.plan,preferences:{...state.plan.preferences,servings:Math.min(state.plan.preferences.servings,MEMBERSHIPS[tier].servings)}},checked:[]};
}
export function toggleFavorite(state:AppState,recipeId:string):AppState {
 const exists=state.favorites.includes(recipeId);
 if(!exists&&state.favorites.length>=MEMBERSHIPS[state.tier].favorites)throw new Error('Your 5 favorites are full. Try the Plus demo for unlimited favorites.');
 return {...state,favorites:exists?state.favorites.filter(id=>id!==recipeId):[...state.favorites,recipeId]};
}
export function storeWeek(state:AppState):AppState {
 const max=MEMBERSHIPS[state.tier].savedWeeks;
 if(!max)throw new Error('Saving weeks is included in Plus and Family.');
 const exists=state.saved.some(p=>p.id===state.plan.id);
 if(!exists&&state.saved.length>=max)throw new Error(`You have ${max} saved weeks. Remove one to save this week.`);
 return {...state,saved:[state.plan,...state.saved.filter(p=>p.id!==state.plan.id)]};
}
export function useSavedWeek(state:AppState,plan:WeekPlan):AppState {
 if(plan.preferences.servings>MEMBERSHIPS[state.tier].servings)throw new Error(`This week needs a plan with ${plan.preferences.servings} servings. Switch your demo membership first.`);
 return {...state,plan,checked:[]};
}
