import test from 'node:test';
import assert from 'node:assert/strict';
import { generateWeek,swapMeal,groceries,MEALS,DEFAULT_PREFS,hydrateState,initialState,startOfWeek,quantity,type Preferences } from '../src/planner.ts';
import { RECIPES,RECIPE_MAP,type Allergen } from '../src/recipes.ts';
const seeded=()=>{let n=41;return()=>{n=(n*16807)%2147483647;return(n-1)/2147483646;};};
test('Every combination of supported preferences produces 21 matching meals',()=>{
 const filters:Allergen[]=['Milk','Egg','Wheat','Soy','Peanut','Tree nut','Fish','Sesame'];
 for(const style of ['everyday','vegetarian'] as const)for(const maxMinutes of [20,30,60] as const)for(let mask=0;mask<256;mask++){
  const avoid=filters.filter((_,i)=>mask&(1<<i));const prefs:Preferences={servings:2,style,maxMinutes,avoid};
  const plan=generateWeek(prefs,seeded());assert.equal(plan.days.length,7);
  for(const day of plan.days)for(const meal of MEALS){const r=RECIPE_MAP[day[meal]];assert.equal(r.meal,meal);assert.ok(r.minutes<=maxMinutes);assert.ok(!r.allergens.some(a=>avoid.includes(a)));if(style==='vegetarian')assert.ok(r.vegetarian);}
 }
});
test('Swapping preserves preferences, other days, and meal slots',()=>{const prefs:Preferences={...DEFAULT_PREFS,style:'vegetarian',avoid:['Milk','Wheat']};const plan=generateWeek(prefs,seeded());const swapped=swapMeal(plan,2,'dinner',seeded());assert.notEqual(swapped.days[2].dinner,plan.days[2].dinner);assert.equal(swapped.days[2].lunch,plan.days[2].lunch);assert.deepEqual(swapped.days[1],plan.days[1]);const r=RECIPE_MAP[swapped.days[2].dinner];assert.ok(r.vegetarian);assert.ok(!r.allergens.includes('Milk')&&!r.allergens.includes('Wheat'));assert.notEqual(swapped,plan);});
test('Grocery totals match all ingredients and scale with servings',()=>{const one=generateWeek({...DEFAULT_PREFS,servings:1},seeded());const four={...one,preferences:{...one.preferences,servings:4}};const list=groceries(one);for(const item of list){const total=one.days.reduce((sum,d)=>sum+MEALS.reduce((s,m)=>s+RECIPE_MAP[d[m]].ingredients.filter(i=>i.name===item.name&&i.unit===item.unit).reduce((a,i)=>a+i.amount,0),0),0);assert.equal(item.amount,total);assert.equal(groceries(four).find(i=>i.key===item.key)!.amount,item.amount*4);}assert.equal(list.length,new Set(list.map(i=>i.key)).size);});
test('Weekly recipes avoid repeats whenever at least seven options match',()=>{const plan=generateWeek({...DEFAULT_PREFS,maxMinutes:60},seeded());for(const meal of MEALS)assert.equal(new Set(plan.days.map(d=>d[meal])).size,7);});
test('Persistence restores data and rejects broken active plans',()=>{const state=initialState();state.tier='family';state.favorites=[RECIPES[0].id];state.saved=[state.plan];const restored=hydrateState(JSON.stringify(state));assert.deepEqual(restored,state);const bad=structuredClone(state);bad.plan.days[0].lunch='not-a-recipe';assert.throws(()=>hydrateState(JSON.stringify(bad)));assert.throws(()=>hydrateState('{'));});
test('Dates, quantity formatting, and serving validation cover edge cases',()=>{assert.equal(startOfWeek(new Date('2026-01-01T12:00:00')),'2025-12-29');assert.equal(quantity(1250,'g'),'1.25 kg');assert.equal(quantity(1500,'ml'),'1.5 L');assert.throws(()=>generateWeek({...DEFAULT_PREFS,servings:0}));assert.throws(()=>generateWeek({...DEFAULT_PREFS,servings:9}));});
