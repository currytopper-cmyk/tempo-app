@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Please install Node.js LTS from https://nodejs.org and then open this file again.
  pause
  exit /b 1
)
node scripts\check-node.cjs
if errorlevel 1 (
  pause
  exit /b 1
)
if not exist node_modules\expo\package.json (
  echo Installing WeekBite. This first step may take a few minutes.
  call npm ci
  if errorlevel 1 (
    echo Installation did not finish. Check your internet connection and try again.
    pause
    exit /b 1
  )
)
echo Open Expo Go on your phone. Keep your phone and computer on the same Wi-Fi.
echo Scan the QR code that appears below. Keep this window open while testing.
call npm start
pause
