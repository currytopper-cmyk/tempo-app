export { default } from './src/WeekBite';
